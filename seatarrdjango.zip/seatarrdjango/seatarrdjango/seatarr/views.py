from lib2to3.pgen2.token import NEWLINE
from pdb import line_prefix
import math
from django.shortcuts import render , redirect
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from datetime import datetime
from django.conf import settings
from django import forms

from seatarr.models import Student
from seatarr.models import Semester
from seatarr.models import Seats
from seatarr.models import Room
from seatarr.models import Teacher
from seatarr.models import Controller

from .forms import AddSemForm
from .forms import AddRoomForm
from .forms import BulkGenForm
from .forms import BulkGenForm2
from .forms import GetSeatForm
from .forms import RoomSelect


from fpdf import FPDF
import xlrd
import xlwt
import tempfile
import os
import io
import re
import zipfile

from  django.contrib.sessions.models import Session 
from django.db.models import Q


def controller(request):
    print(dict(request.session))
    if request.session.get('admin_signed_in') == True:

        return render(request, "seatarr/controller.html")
    return redirect("/signin_controller")

def teacher(request):

    if request.session.get('teacher_signed_in') == True:
        return render( request ,"seatarr/teacher.html")
    return redirect("/signin") 


def attendence(request):

    if request.session.get("teacher_signed_in") ==  True:

        attendence = []
        examClass = ""

        if request.method == "POST":
            request_type = request.POST.get("type")
            
            if request_type == "getClass":

                examClass = request.POST.get("class")

                students = Seats.objects.all().filter( seat_studentid__contains = examClass ).values_list()
                print(students)

                attendence = students
            
            elif request_type == "submitAttendence":
                print("submitted attendece")
                examClass = request.POST.get("class")
                print(request.POST)
                print(examClass)
                students = Seats.objects.all().filter( seat_studentid__contains = examClass ).values_list()

                for index , item in enumerate(list(students)):
                    print(item)
                    seat = Seats.objects.all().filter( seat_studentid__contains = examClass , seat_studentid = item[1] )[0]
                    print(seat)

                    present = False

                    if request.POST.get(item[1]) is not None:

                        present = True
                    print(present)
                    seat.seat_attendence = present 
                    seat.save()

                    
                 
                    # seat.seat_attendence = request.POST.get(item)

                students = Seats.objects.all().filter( seat_studentid__contains = examClass ).values_list()
                attendence = students



                

        return render( request , "seatarr/attendence.html" , {'attendence': attendence, 'class': examClass})
    
    return redirect("/signin")

def report_malpractice(request):

    if request.session.get("teacher_signed_in") == True:
        
        if request.method == "POST":
            roll_no = request.POST.get("roll_no")
            remarks = request.POST.get("remarks")

            seat = Seats.objects.all().filter( seat_studentid = roll_no )[0]
            seat.seat_malpractice_remarks = remarks
            seat.save()

            return redirect("/")

    
        return render(request ,"seatarr/report_malpractice.html" )
    else:
        return redirect("/signin")


def view_seating(request):

    seatings = list(Seats.objects.all().values_list())
    print(seatings)
    # print(seatings)
    
    pages = []
    print(len(seatings))
    page_size = 60
    for i in range(math.ceil(len(seatings)/page_size)):

        if i*page_size + page_size < len(seatings):
            page =  seatings[i*page_size:i*page_size+page_size]
        else:
            page = seatings[i*page_size:len(seatings)] 
        print(len(page))
        if len(page) < page_size//2:
            print("here")
            column1 = page[0: len(page)]
            column2 = []
        else :
            column1 =  page[0:page_size//2]
            column2 = page[page_size//2: len(page)]
        pages.append([column1 , column2])

    print("the pages are " , pages)

    
    return render(request , "seatarr/view_seating.html" , { 'pages': pages})

def view_classwise_seating(request):

    rooms = Seats.objects.values("seat_class").distinct().values_list("seat_class", flat = True)
    sems = list(Semester.objects.values("semester_name").distinct().values_list("semester_name", flat = True))
    
    seats=  Seats.objects.all().values_list()
    
    print("rooms are" , rooms)
    print("sems are ", sems)

    room_roll_list = {}
    
    for room in list(rooms):
        room_roll_list[room] = {}

    print(rooms)

    for seat in seats:
        
        room = seat[2]
        for sem in sems:
            if sem in seat[1]:
                if room_roll_list.get(room).get(sem) is  None:
                    room_roll_list[room][sem] = []
                room_roll_list[room][sem].append(seat[1])
                

    # print(room_roll_list)

    final_list = []

    for room in room_roll_list:
        for sem in room_roll_list[room]:
            room_roll_list[room][sem].sort()
            rollRange = room_roll_list[room][sem] 
            final_list.append( [ room , sem ,   [rollRange[0] , rollRange[-1]]])

    print(final_list)


    return render(request , "seatarr/view_classwise_seating.html", {'list' : final_list})
    

def index(request):
    return render(request , "seatarr/index.html")



def upload(request):
    rooms = Room.objects.all()
    return render(request, "seatarr/upload.html", {"types": rooms})


def bulkgen(request):
    form = BulkGenForm()
    return render(request, "seatarr/bulkgen.html", {"form": form})


def addsem(request):
    form = AddSemForm()
    return render(request, "seatarr/addsem.html", {"form": form})


def addroom(request):
    form = AddRoomForm()
    return render(request, "seatarr/addroom.html", {"form": form})

def addTeacher(request):

    if request.method == "POST":
        teacher_name = request.POST.get("teacher_name")
        teacher_email = request.POST.get("teacher_email")
        teacher_password = request.POST.get("teacher_password")

        teacher = Teacher(
            teacher_name = teacher_name , 
            teacher_email = teacher_email,
            teacher_password = teacher_password
        )
        teacher.save()
        return redirect("/controller")
    
    return render( request , "seatarr/add_teacher.html")

def logout_teacher(request):
    request.session['teacher_signed_in']  = False 
    return redirect("/")

def controller_logout(request):
    request.session['admin_signed_in']  = False 
    return redirect("/controller")


def getseats(request):
    form = GetSeatForm()
    return render(request, "seatarr/getseats.html", {"form": form})


def roomselect(request):
    form = RoomSelect()
    return render(request, "seatarr/roomselect.html", {"form": form})


def addsemtodb(request):
    if request.method == "POST":
        form = AddSemForm(request.POST)
        if form.is_valid():
            newSemester = Semester(
                semester_name=form.cleaned_data["semName"],
                semester_rollstart=form.cleaned_data["rollStart"],
                semester_rollend=form.cleaned_data["rollEnd"],
                semester_rollmiss=form.cleaned_data["rollMiss"],
                semester_subcodes=form.cleaned_data["subCodes"],
            )
            newSemester.save()
            return HttpResponseRedirect("/controller")
    else:
        form = AddSemForm()
    return render(request, "seatarr/addsem.html", {"form": form})


def addroomtodb(request):
    if request.method == "POST":
        form = AddRoomForm(request.POST)
        if form.is_valid():
            newRoom = Room(
                room_name=form.cleaned_data["roomName"],
                room_size=form.cleaned_data["roomSize"],
            )
            newRoom.save()
            return HttpResponseRedirect("/controller")
    else:
        form = AddRoomForm()
    return render(request, "seatarr/addroom.html", {"form": form})


def bulk(request):
    rooms = list(Room.objects.all().values_list())
    print(rooms)
    if request.method == "POST":
        form = BulkGenForm(request.POST)
        if form.is_valid():
            semname = []
            for name in form.cleaned_data["semOptions"]:
                semname.append(name)
            form2 = BulkGenForm2(extra=len(semname), sems=semname)
            return render(request, "seatarr/bulkgen2.html", {"form": form2  , "rooms": rooms  , "sems" : len(semname)})
    else:
        form = BulkGenForm()

    return render(request, "seatarr/bulkgen.html", {"form": form , "rooms": rooms})

def bulk2(request):
    if request.method == "POST":
        form = BulkGenForm2(request.POST)
        rooms = []
        # if form.is_valid():
        Student.objects.all().delete()
        # roomsize = request.POST["roomType"]
        # roomsize = re.search(r"\(([0-9]+)\)", roomsize[-5:])
        # roomsize = roomsize.group(1)
        # roomsize = int(roomsize)
        print("class count is " , request.POST.get("classCount"))
        count = int(request.POST.get("classCount"))
        for i in range(1 , count+1):
            room_number = request.POST.get(f"room_number{i}")
            room_type =  request.POST.get(f"room_type{i}")
            room_size = Room.objects.filter( room_name = room_type ).values_list()[0][2]
            rooms.append( [room_number , room_size])
        print(rooms)

        student_count = 0
        
        
        for i in range(0, int(request.POST.get("sems"))):
            semName = request.POST.get(f"sem{i}").split(":")[0]
            rollstart = (
                Semester.objects.values("semester_rollstart")
                .filter(semester_name=semName)
                .values_list("semester_rollstart", flat=True)
            )
            rollend = (
                Semester.objects.values("semester_rollend")
                .filter(semester_name=semName)
                .values_list("semester_rollend", flat=True)
            )
            rollmiss = (
                Semester.objects.values("semester_rollmiss")
                .filter(semester_name=semName)
                .values_list("semester_rollmiss", flat=True)
            )
            rollmisslist = rollmiss[0].split()
            missdict = dict()
            for idx, ele in enumerate(rollmisslist):
                missdict[idx] = ele
            for x in range(rollstart[0], rollend[0] + 1):
                if f"{x}" in missdict.values():
                    continue
                subject = request.POST.get(f"sem{i}").split(":")[1].strip()
                print(subject)
                # print(request.POST.get(f"sem{i}")).split(":")[1].strip()
                newStudent = Student(
                    student_name=x,
                    student_regno=semName + f"{x}",
                    student_sub=subject,
                )
                newStudent.save()
                student_count +=1

        seat_count = 0
        for room in rooms:
            seat_count+= room[1]
        
        if seat_count < student_count:
            return render( request , "seatarr/seatlimt.html")
        
        print(rooms)
        createplan(rooms)
        return render(request, "seatarr/index.html")
    return render(request, "seatarr/index.html")


def changerooms(request):
    if request.method == "POST":
        form = RoomSelect(request.POST)
        if form.is_valid():
            fieldNames = request.POST.get(f"fieldNames").split("-")
            for i in range(0, int(request.POST.get("numFields"))):
                roomName = request.POST.get(f"room{i}")
                record = Seats.objects.all().filter(seat_class=fieldNames[i])
                for rec in record:
                    rec.seat_class = "TEMPTEMPTEMP" + roomName
                    rec.save()
            record = Seats.objects.all()
            for rec in record:
                if "TEMPTEMPTEMP" in rec.seat_class:
                    rec.seat_class = rec.seat_class[12:]
                    rec.save()
    return render(request, "seatarr/index.html")


def createplan(rooms):
    
    
    
    numClasses = 200
    # numSeats = maxSize * numClasses
    numStudents = Student.objects.count()

    subjects = (
        Student.objects.values("student_sub")
        .distinct()
        .values_list("student_sub", flat=True)
    )
    Seats.objects.all().delete()
    curRow = 1
    row1, row2 = 1, 2
    row1room, row2room = 100, 100
    print(subjects)
    for sub in subjects:
        current_room_index = 0
        current_room = rooms[current_room_index]
        maxSize =  current_room[1]
        details = (
            Student.objects.values("student_regno")
            .filter(student_sub=sub)
            .values_list("student_regno", flat=True)
        )
        print(details)
        for student in details:
            if curRow == 1:
                seat = Seats(
                    seat_studentid=student,
                    seat_class=f"{row1room}",
                    seat_number=f"{row1}",
                    seat_attendence = False , 
                    seat_malpractice_remarks  = ""
                )
                seat.save()
                row1 += 2
                if row1 >= maxSize:
                    current_room_index+=1
                    row1room = rooms[ current_room_index ][0]
                    maxSize = rooms [  current_room_index ][1]
                    row1 = 1
            else:
                seat = Seats(
                    seat_studentid=student,
                    seat_class=f"{row2room}",
                    seat_number=f"{row2}",
                    seat_attendence = False , 
                    seat_malpractice_remarks  = ""
                )
                seat.save()
                row2 += 2
                if row2 - 1 >= maxSize:
                    row2room = rooms[ current_room_index + 1][0]
                    row2 = rooms [  current_room_index + 1][1]
                    row2 = 2
        # if int(row1room) * 100 + row1 > int(row2room) * 100 + row2:
        if curRow  == 1:
            curRow = 2
        else:
            curRow = 1
    # while row1room <= row2room:
        # while row1 < maxSize:
            # seat = Seats(
                # seat_studentid="", seat_class=f"{row1room}", seat_number=f"{row1}",
                #  seat_attendence = False , 
            # )
            # seat.save()
            # row1 += 2
        # row1room += 1
        # row1 = 1
        # if row1room > row2room:
            # row1room -= 1
            # break
    # while row2room <= row1room:
        # while row2 - 1 < maxSize:
            # seat = Seats(
                # seat_studentid="", seat_class=f"{row2room}", seat_number=f"{row2}",
                #  seat_attendence = False , 
            # )
            # seat.save()
            # row2 += 2
        # row2room += 1
        # row2 = 2


def load(request):
    if request.method == "POST":
        files = request.FILES.getlist("files")
        roomsize = request.POST.get("roomtype")
        roomsize = re.search(r"\(([0-9]+)\)", roomsize[-5:])
        roomsize = roomsize.group(1)
        roomsize = int(roomsize)
        Student.objects.all().delete()
        for f in files:
            book = xlrd.open_workbook(filename=None, file_contents=f.read())
            sheet = book.sheet_by_index(0)
            i = 2
            while i < sheet.nrows:
                newStudent = Student(
                    student_name=sheet.cell(i, 0).value,
                    student_regno=sheet.cell(i, 1).value,
                    student_sub=sheet.cell(i, 3),
                )
                newStudent.save()
                i += 1
        createplan(roomsize)
    return render(request, "seatarr/index.html")


def createpdf():
    rno = 100
    pdf = FPDF()
    pdf.add_page()

    col_width = 70
    font_style = "Helvetica"
    header_font_size = 20
    footer_font_size = 12
    cell_font_size = 14
    cell_centering_gap = 25
    index_column_width = 10
    pdf.set_font(font_style, size=header_font_size, style="B")
    line_height = pdf.font_size * 1.45
    rooms = (
        Seats.objects.values("seat_class")
        .distinct()
        .values_list("seat_class", flat=True)
    )

    for room in rooms:
        details = (
            Seats.objects.filter(seat_class=room)
            .order_by("seat_number")
            .values_list("seat_studentid", flat=True)
        )
        seatnos = (
            Seats.objects.filter(seat_class=room)
            .order_by("seat_number")
            .values_list("seat_number", flat=True)
        )
        pdf.set_font(font_style, size=header_font_size, style="B")
        pdf.cell(
            0, line_height, "Sree Chithra Thirunal College of Engineering", align="C"
        )
        pdf.ln(h=10)
        pdf.set_font(font_style, size=footer_font_size, style="")
        pdf.multi_cell(0, line_height, "Pappanamcode, Trivandrum", align="C")
        pdf.set_font(font_style, size=cell_font_size, style="B")
        pdf.cell(cell_centering_gap)
        pdf.set_fill_color(26, 162, 96)
        pdf.multi_cell(
            col_width * 2, line_height, f"Room {room}", border=1, align="C", fill=True
        )
        pdf.cell(cell_centering_gap)
        pdf.set_fill_color(210, 210, 210)
        pdf.cell(index_column_width, line_height, "No.", border=1, align="C", fill=True)
        pdf.cell(
            col_width - index_column_width,
            line_height,
            "Roll No",
            border=1,
            align="C",
            fill=True,
        )
        pdf.cell(index_column_width, line_height, "No.", border=1, align="C", fill=True)
        pdf.multi_cell(
            col_width - index_column_width,
            line_height,
            "Roll No",
            border=1,
            align="C",
            fill=True,
        )
        pdf.set_font(font_style, size=cell_font_size, style="")
        rno += 1
        pdf.set_fill_color(241, 241, 241)
        for i in range(0, len(details) - 1, 2):
            if details[i] == "" and details[i + 1] == "":
                continue
            pdf.cell(cell_centering_gap)
            pdf.cell(
                index_column_width,
                line_height,
                f"{i + 1}",
                border=1,
                align="C",
                fill=True,
            )
            pdf.cell(
                col_width - index_column_width,
                line_height,
                details[i],
                border=1,
                align="C",
                fill=True,
            )
            pdf.cell(
                index_column_width,
                line_height,
                f"{i + 2}",
                border=1,
                align="C",
                fill=True,
            )
            pdf.multi_cell(
                col_width - index_column_width,
                line_height,
                details[i + 1],
                border=1,
                align="C",
                fill=True,
            )
        pdf.ln(line_height)
        pdf.add_page()
    return pdf


def createpdfinvig():
    pdf = FPDF()
    pdf.set_auto_page_break(0)
    pdf.add_page()

    col_width = 70
    font_style = "Helvetica"
    header_font_size = 20
    footer_font_size = 12
    cell_font_size = 14
    cell_centering_gap = 25
    index_column_width = 10
    pdf.set_font(font_style, size=header_font_size, style="B")
    line_height = pdf.font_size * 1.05
    print(line_height)
    perpage = 0
    rooms = (
        Seats.objects.values("seat_class")
        .distinct()
        .values_list("seat_class", flat=True)
    )
    rows = 0
    for room in rooms:
        details = (
            Seats.objects.filter(seat_class=room)
            .order_by("seat_number")
            .values_list("seat_studentid", flat=True)
        )
        pdf.set_font(font_style, size=header_font_size, style="B")
        pdf.cell(
            0, line_height, "Sree Chithra Thirunal College of Engineering", align="C"
        )
        pdf.ln(h=10)
        pdf.set_font(font_style, size=footer_font_size, style="")
        pdf.multi_cell(0, line_height, "Pappanamcode, Trivandrum", align="C")
        pdf.cell(cell_centering_gap)
        pdf.set_font(font_style, size=footer_font_size, style="")
        pdf.cell(col_width, line_height, "Date: ", align="L")
        pdf.multi_cell(col_width, line_height, "FN/AN", align="R")
        pdf.cell(cell_centering_gap)
        pdf.set_font(font_style, size=cell_font_size, style="B")
        pdf.set_fill_color(255, 206, 68)
        pdf.multi_cell(
            col_width * 2, line_height, f"Room {room}", border=1, align="C", fill=True
        )
        pdf.cell(cell_centering_gap)
        pdf.set_fill_color(210, 210, 210)
        pdf.cell(
            col_width, line_height, "Register/Roll No.", border=1, align="C", fill=True
        )
        pdf.multi_cell(
            col_width, line_height, "Absentees", border=1, align="C", fill=True
        )
        pdf.set_font(font_style, size=cell_font_size - 2, style="B")
        pdf.set_fill_color(241, 241, 241)
        regstarts = []
        regnos = []
        type = 0
        for i in details:
            regnos.append(i[0:])
        regnos.sort()

        for i in details:
            if len(i) >= 7:
                type = 1
                if "LSCT" in i or "RSCT" in i:
                    regstarts.append(i[0:8])
                else:
                    regstarts.append(i[0:7])
            elif i == "" or i == ".":
                continue
            else:
                type = 2
                if len(i) == 5:
                    regstarts.append(i[0:2])
                else:
                    regstarts.append(i[0:3])
        unqregstarts = set(regstarts)
        maxval, minval = "000", "999"
        count = 0
        prev = ""
        prevstart = ""
        endofrange = ""
        ranged = False
        finalstr = ""
        maxcharperrow = 30
        for i in regnos:
            if len(i) >= 0:
                start = ""
                start = i[0:len(i) - 3]
                if prev == "":
                    prev = i
                    prevstart = start
                    finalstr += i
                    count += 1
                    continue
                if prevstart == start:
                    if int(i[-3:]) - 1 == int(prev[-3:]):
                        ranged = True
                        endofrange = i
                        count += 1
                    else:
                        if not ranged:
                            finalstr += ", " + i[-3:]
                            count += 1
                        else:
                            finalstr += " - " + endofrange[-3:] + f" [{count}]"
                            newlinegapmultiplier = len(finalstr) / maxcharperrow + 1
                            pdf.cell(cell_centering_gap)
                            pdf.multi_cell(
                                col_width,
                                line_height,
                                finalstr,
                                align="C",
                                fill=True,
                                border=1,
                            )
                            rows += newlinegapmultiplier
                            finalstr = i
                            count = 1
                        ranged = False
                else:
                    if not ranged:
                        finalstr += f" [{count}]"
                        newlinegapmultiplier = len(finalstr) / maxcharperrow + 1
                        pdf.cell(cell_centering_gap)
                        pdf.multi_cell(
                            col_width,
                            line_height,
                            finalstr,
                            align="C",
                            fill=True,
                            border=1,
                        )
                        rows += newlinegapmultiplier
                        finalstr = i
                        count = 1
                    else:
                        finalstr += " - " + endofrange[-3:] + f" [{count}]"
                        newlinegapmultiplier = len(finalstr) / maxcharperrow + 1
                        pdf.cell(cell_centering_gap)
                        pdf.multi_cell(
                            col_width,
                            line_height,
                            finalstr,
                            align="C",
                            fill=True,
                            border=1,
                        )
                        rows += newlinegapmultiplier
                        finalstr = i
                        count = 1
                    ranged = False
                prev = i
                prevstart = start
        if not ranged:
            finalstr += f" [{count}]"
            newlinegapmultiplier = len(finalstr) / maxcharperrow + 1
            pdf.cell(cell_centering_gap)
            pdf.multi_cell(
                col_width,
                line_height,
                finalstr,
                align="C",
                fill=True,
                border=1,
            )
            rows += newlinegapmultiplier
            finalstr = i
            count = 1
        else:
            finalstr += " - " + endofrange[-3:] + f" [{count}]"
            newlinegapmultiplier = len(finalstr) / maxcharperrow + 1
            pdf.cell(cell_centering_gap)
            pdf.multi_cell(
                col_width,
                line_height,
                finalstr,
                align="C",
                fill=True,
                border=1,
            )
            rows += newlinegapmultiplier
            finalstr = i
            count = 1

        pdf.set_font(font_style, size=footer_font_size, style="")
        pdf.multi_cell(col_width * 2, line_height - 2)
        pdf.multi_cell(
            col_width * 2, line_height - 2, "Name of invigilator(s)", align="C"
        )
        pdf.multi_cell(col_width * 2, line_height - 2)
        perpage += 1
        if perpage == 4 or rows > 16:
            pdf.add_page()
            rows = 0
            perpage = 0
    return pdf


def createpdfnotice():
    pdf = FPDF()
    pdf.add_page()
    roomdetails = []
    col_width = 70
    font_style = "Helvetica"
    header_font_size = 20
    footer_font_size = 12
    cell_font_size = 14
    cell_centering_gap = 25
    index_column_width = 10
    pdf.set_font(font_style, size=header_font_size, style="B")
    line_height = pdf.font_size * 1.05
    pdf.set_font(font_style, size=header_font_size, style="B")
    pdf.cell(0, line_height, "Sree Chithra Thirunal College of Engineering", align="C")
    pdf.ln(h=10)
    pdf.set_font(font_style, size=footer_font_size, style="")
    pdf.multi_cell(0, line_height, "Pappanamcode, Trivandrum", align="C")
    pdf.set_font(font_style, size=cell_font_size, style="B")
    pdf.cell(cell_centering_gap)
    pdf.set_fill_color(222, 82, 70)
    pdf.multi_cell(
        col_width * 2, line_height, f"Notice", border=1, align="C", fill=True
    )
    pdf.cell(cell_centering_gap)
    pdf.set_fill_color(210, 210, 210)
    pdf.cell(
        col_width, line_height, "Register/Roll Nos.", border=1, align="C", fill=True
    )
    pdf.multi_cell(col_width, line_height, "Room No.", border=1, align="C", fill=True)
    pdf.set_font(font_style, size=cell_font_size - 2, style="B")
    pdf.set_fill_color(241, 241, 241)
    rooms = (
        Seats.objects.values("seat_class")
        .distinct()
        .values_list("seat_class", flat=True)
    )
    type = 0
    for room in rooms:
        details = (
            Seats.objects.filter(seat_class=room)
            .order_by("seat_number")
            .values_list("seat_studentid", flat=True)
        )
        regstarts = []
        
        for i in details:
            if len(i) > 7:
                type = 1
                if "LSCT" in i or "RSCT" in i:
                    regstarts.append(i[0:8])
                else:
                    regstarts.append(i[0:7])
            elif i == "" or i == ".":
                continue
            else:
                type = 2
                if len(i) == 5:
                    regstarts.append(i[0:2])
                else:
                    regstarts.append(i[0:3])
        unqregstarts = set(regstarts)
        maxval, minval = "000", "999"
        for i in unqregstarts:
            maxval, minval = "000", "999"
            for j in details:
                if type == 1:
                    if i in j and i[0] == j[0]:
                        val = int(j[-3:])
                        if val > int(maxval):
                            if val != int(maxval) + 1 and maxval != "000" and minval != "999":
                                roomdetails.append([i, room, f"{i}{minval}", f"{i}{maxval}"])
                                minval = j[-3:]
                                maxval = j[-3:]
                                continue
                            if minval == "999" and maxval == "000":
                                minval = maxval = j[-3:]
                            maxval = j[-3:]
                        if val < int(minval):
                            if minval == "999" and maxval == "000":
                                minval = maxval = j[-3:]
                            else:
                                roomdetails.append([i, room, f"{i}{minval}", f"{i}{maxval}"])
                                minval = maxval = j[-3:]
                            minval = j[-3:]
                elif j == "." or j == "":
                    continue
                else:
                    if i in j:
                        val = int(j[-3:])
                        if val > int(maxval[-3:]):
                            if val != int(maxval) + 1 and maxval != "000" and minval != "999":
                                roomdetails.append([i, room, minval, maxval])
                                minval = j[-3:]
                                maxval = j[-3:]
                                continue
                            maxval = j[-3:]
                        if val < int(minval[-3:]):
                            minval = j[-3:]
            if type == 1:
                roomdetails.append([i, room, f"{i}{minval}", f"{i}{maxval}"])
            else:
                roomdetails.append([i, room, minval, maxval])
    if type == 1:
        roomdetails.sort(key = lambda x : (x[0][-2:], x[2]))
    else:
        roomdetails.sort()
    prev = roomdetails[0][0]
    count = 0
    limit = 19
    top = True
    cur = ""
    for i in roomdetails:
        if i[0][-2:] != cur and type == 1:
            pdf.set_font(font_style, size=cell_font_size, style="B")
            pdf.cell(cell_centering_gap)
            pdf.set_fill_color(210, 210, 210)
            pdf.multi_cell(
                col_width * 2, line_height, f"{i[0][-2:]}", border=1, align="C", fill=True
            )
            pdf.set_font(font_style, size=cell_font_size - 2, style="B")
            pdf.set_fill_color(241, 241, 241)
            cur = i[0][-2:]
            count += 1
        pdf.cell(cell_centering_gap)
        cell_border = "LR"
        
        if i[0] != prev:
            cell_border = "LRT"
        if type == 1:
            if i[0][-2:] == prev[-2:]:
                cell_border = "LR"
        if i == roomdetails[-1] or count == limit:
            cell_border = "LRB"
            limit = 24
            count = 0
        elif count == 1 and top != True:
            cell_border = "LRT"
        if count == 1:
            top = False
        if i[2] == i[3]:
            pdf.cell(
                col_width,
                line_height,
                f"{i[2]}",
                align="C",
                fill=True,
                border=cell_border,
            )
        else:
            pdf.cell(
                col_width,
                line_height,
                f"{i[2]} - {i[3][-3:]}",
                align="C",
                fill=True,
                border=cell_border,
            )
        pdf.multi_cell(
            col_width, line_height, f"{i[1]}", align="C", fill=True, border=cell_border
        )
        count += 1
        prev = i[0]
    return pdf


def createseatsxl():
    book = xlwt.Workbook()
    sheet = book.add_sheet('0')

    idx = 0
    for seat in Seats.objects.all():
        if len(seat.seat_studentid) > 1:
            sheet.write(idx, 0, seat.seat_studentid)
            sheet.write(idx, 1, seat.seat_class)
            sheet.write(idx, 2, seat.seat_number)
            idx+=1

    buff = io.BytesIO()
    book.save(buff)
    return buff


def create(request):
    # pdf1 = createpdf()
    # pdf2 = createpdfinvig()
    # pdf3 = createpdfnotice()
    xl   = createseatsxl()

    # result1 = pdf1.output("seats.pdf", "S").encode("latin-1")
    # result2 = pdf2.output("invig.pdf", "S").encode("latin-1")
    # result3 = pdf3.output("notice.pdf", "S").encode("latin-1")
    
    buff = io.BytesIO()
    zf = zipfile.ZipFile(buff, "w")
    # zf.writestr("seats.pdf", result1)
    # zf.writestr("invig.pdf", result2)
    # zf.writestr("notice.pdf", result3)
    zf.writestr("siteupload.xls", xl.getvalue())
    zf.close()
    response = HttpResponse(
        buff.getvalue(), content_type="application/x-zip-compressed"
    )
    response["Content-Disposition"] = "attachment; filename=plan.zip"
    return response


def get(request):
    if request.method == "POST":

        form = GetSeatForm(request.POST)
        if form.is_valid():
            studentClass = (
                Seats.objects.values("seat_class")
                .filter(seat_studentid=form.cleaned_data["studentId"])
                .values_list("seat_class", flat=True)
            )
            studentSeat = (
                Seats.objects.values("seat_number")
                .filter(seat_studentid=form.cleaned_data["studentId"])
                .values_list("seat_number", flat=True)
            )
            if( len(studentClass) > 0 and len(studentSeat) > 0):
                return render(
                    request,
                    "seatarr/seatresult.html",
                    {"studentclass": studentClass[0], "studentseat": studentSeat[0]},
                )
            else:
                return render(
                    request,
                    "seatarr/seatresult.html",
                    {"studentclass": -1, "studentseat": -1},
                )
    else:
        form = GetSeatForm()
    return render(request, "seatarr/getseats.html", {"form": form})

def clear(request):
    Semester.objects.all().delete()
    Student.objects.all().delete()
    Seats.objects.all().delete()
    Room.objects.all().delete()
    return redirect("/controller")


def signin_controller(request):

    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        print(email , password)

        
        print( Controller.objects.all().values_list())
        controllers = Controller.objects.all().filter( controller_email = email , controller_password =  password ).values_list()
        print(controllers)

        print("reached here")

        if len(list(controllers)) > 0:
            request.session['admin_signed_in'] = True
            print("signed in")
            return redirect("/controller/")

        


    return render( request , "seatarr/signin_controller.html")

def signin(request):

    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")

        print(email , password)

        teachers = Teacher.objects.all().filter( teacher_email = email , teacher_password =  password ).values_list()
        print(teachers)

        print("reached here")

        if len(list(teachers)) > 0:
            request.session['teacher_signed_in'] = True
            print("signed in")
            return redirect("/")

        


    return render( request , "seatarr/signin.html")
    

def malpractice(request):
    malpractices = Seats.objects.all().filter( ~Q(seat_malpractice_remarks = ""))
    for item in malpractices:
        print( item.seat_studentid)
        print( item.seat_malpractice_remarks)

    print(malpractices)

    return render( request ,"seatarr/view_malpractices.html" ,{"malpractices" : malpractices})