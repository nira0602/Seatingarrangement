from django.apps import AppConfig


class seatarrConfig(AppConfig):
    name = 'seatarr'
