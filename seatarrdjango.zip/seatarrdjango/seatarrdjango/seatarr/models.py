from django.db import models


class Student(models.Model):
    student_name = models.CharField(max_length=200)
    student_regno = models.CharField(max_length=30)
    student_sub = models.CharField(max_length=200)
    


class Semester(models.Model):
    semester_name = models.CharField(max_length=100)
    semester_rollstart = models.IntegerField()
    semester_rollend = models.IntegerField()
    semester_rollmiss = models.CharField(max_length=500)
    semester_subcodes = models.CharField(max_length=1000)

    def __str__(self):
        return self.semester_name


class Room(models.Model):
    room_name = models.CharField(max_length=100)
    room_size = models.IntegerField()

    def __str__(self):
        return f"{self.room_name} ({self.room_size})"


class Seats(models.Model):
    seat_studentid = models.CharField(max_length=30)
    seat_class = models.CharField(max_length=20)
    seat_number = models.IntegerField()
    seat_attendence = models.BooleanField(default=False)
    seat_malpractice_remarks = models.CharField(max_length= 255 ) 



class Teacher(models.Model):
  
    teacher_name = models.CharField(max_length=100)
    teacher_email = models.CharField(max_length=100)
    teacher_password = models.CharField(max_length=100)

class Controller(models.Model):
    
    controller_email = models.CharField(max_length=100)
    controller_password = models.CharField(max_length=100)
