from django import forms

from seatarr.models import Semester
from seatarr.models import Seats
from seatarr.models import Room


class AddSemForm(forms.Form):
    semName = forms.CharField(label="Semester name", max_length=100, required=True)
    rollStart = forms.IntegerField(label="Roll number (start)", required=True)
    rollEnd = forms.IntegerField(label="Roll number (end)", required=True)
    rollMiss = forms.CharField(
        label="Missing roll numbers",
        widget=forms.Textarea(attrs={"rows": 4}),
        required=False,
    )
    subCodes = forms.CharField(
        label="Subject codes", widget=forms.Textarea(attrs={"rows": 3}), required=False
    )


class AddRoomForm(forms.Form):
    roomName = forms.CharField(label="Class type", max_length=100, required=True)
    roomSize = forms.IntegerField(label="Maximum size", required=True)


class BulkGenForm(forms.Form):
    options = Semester.objects.all()
    semOptions = forms.ModelMultipleChoiceField(
        queryset=options, label="Semester options"
    )


class BulkGenForm2(forms.Form):
    @property
    def checked_range(self):
        return range(self.fields["numFields"].initial)

    def __init__(self, *args, **kwargs):
        extra_fields = kwargs.pop("extra", 0)
        sems = kwargs.pop("sems", 0)
        super(BulkGenForm2, self).__init__(*args, **kwargs)
        self.fields["numFields"] = forms.IntegerField(
            initial=int(extra_fields), widget=forms.HiddenInput(), required=False
        )
        for index in range(int(extra_fields)):
            subcodes = ""
            fromdb = (
                Semester.objects.values("semester_subcodes")
                .filter(semester_name=sems[index])
                .values_list("semester_subcodes", flat=True)
            )
            for i in fromdb:
                subcodes += i
            subcodes = subcodes.split("\n")
            finalchoices = []
            for i in subcodes:
                finalchoices.append((f"{sems[index]}:{i}", i))
            self.fields[f"sem{index}"] = forms.CharField(
                max_length=100, widget=forms.Select(choices=finalchoices)
            )
            self.fields[f"sem{index}"].label = f"{sems[index]}"
        roomTypes = Room.objects.all()
        finalroomtypes = []
        for i in roomTypes:
            finalroomtypes.append((f"{i}", i))
        self.fields["roomType"] = forms.CharField(
            label="Class type",
            max_length=100,
            widget=forms.Select(choices=finalroomtypes),
        )


class RoomSelect(forms.Form):
    def __init__(self, *args, **kwargs):
        super(RoomSelect, self).__init__(*args, **kwargs)
        rooms = (
            Seats.objects.values("seat_class")
            .distinct()
            .values_list("seat_class", flat=True)
        )
        roomsstr = "-".join([str(i) for i in rooms])
        self.fields["numFields"] = forms.IntegerField(
            initial=len(rooms), widget=forms.HiddenInput(), required=False
        )
        self.fields["fieldNames"] = forms.CharField(
            initial=roomsstr, widget=forms.HiddenInput(), required=False
        )

        for index in range(len(rooms)):
            self.fields[f"room{index}"] = forms.CharField(
                initial=f"{rooms[index]}", max_length=100, required=True
            )
            self.fields[f"room{index}"].label = f"{rooms[index]}"


class GetSeatForm(forms.Form):
    studentId = forms.CharField(
        label="Register/roll number", max_length=10, required=True
    )
