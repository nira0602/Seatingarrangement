"""
Package for seatarrdjango.
"""
