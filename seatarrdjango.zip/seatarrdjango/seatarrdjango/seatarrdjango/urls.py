from django.contrib import admin
from django.urls import include, path

from seatarr import views

urlpatterns = [
    path("", views.teacher, name="teacher"),
    path("controller/", views.controller, name="controller"),
    path("attendence/", views.attendence, name="attendence"),
    path("report_malpractice/", views.report_malpractice, name="attendence"),
    path("view_seating/", views.view_seating, name="view_seating"),
    path("view_classwise_seating/", views.view_classwise_seating, name="view_seating"),

    path("controller/add_teacher", views.addTeacher, name="add_teacher"),
    path("addsem/", views.addsem, name="addsem"),
    path("addroom/", views.addroom, name="addroom"),
    path("bulkgen/", views.bulkgen, name="bulkgen"),
    path("upload/", views.upload, name="upload"),
    path("roomselect/", views.roomselect, name="roomselect"),
    path("getseats/", views.getseats, name="getseats"),
    path("load/", views.load, name="load"),
    path("addsemtodb/", views.addsemtodb, name="addsemtodb"),
    path("addroomtodb/", views.addroomtodb, name="addroomtodb"),
    path("bulk/", views.bulk, name="bulk"),
    path("bulk2/", views.bulk2, name="bulk2"),
    path("signin_controller/", views.signin_controller, name="signin_controller"),
    path("logout_teacher/", views.logout_teacher, name="logout_teacher"),
    path("controller_logout/", views.controller_logout, name="controller_logout"),
    path("signin/", views.signin, name="signin"),
    path("get/", views.get, name="get"),
    path("create/", views.create, name="create"),
    path("get_malpractices/", views.malpractice, name="malpractice"),
    # path("create/", views.generatePdf, name="create"),
    path("changerooms/", views.changerooms, name="changerooms"),
    path("clear/", views.clear, name="clear"),
    path("admin/", admin.site.urls),
    
]
